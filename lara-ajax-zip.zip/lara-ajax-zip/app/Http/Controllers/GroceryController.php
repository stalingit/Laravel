<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Grocery;

class GroceryController extends Controller
{
    public function store(Request $request)
    {
        $validator = \Validator::make($request->all(), [
            'name' => 'required',
            'type' => 'required',
            'price' => 'required',
        ]);
        
        if ($validator->fails())
        {
            return response()->json(['errors'=>$validator->errors()->all()]);
        }
       
           $grocery = new Grocery();
           $grocery->name = $request->name;
           $grocery->type = $request->type;
           $grocery->price = $request->price;
   
           $grocery->save();
           return response()->json(['success'=>'Data is successfully added']);
    }
}
