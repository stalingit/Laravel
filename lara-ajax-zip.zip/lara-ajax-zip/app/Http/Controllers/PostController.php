<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;

class PostController extends Controller
{
    public function index(){
        return view('row');
      }
    
      // Fetch records
      public function getUsers(){
        // Call getuserData() method of Page Model
        $userData['data'] = Post::getuserData();
    
        echo json_encode($userData);
        exit;
      }
    
      // Insert record
      public function addUser(Request $request){
    
        $name = $request->input('name');
        $username = $request->input('username');
        $email = $request->input('email');
    
        if($name !='' && $username !='' && $email != ''){
          $data = array('name'=>$name,"username"=>$username,"email"=>$email);
    
          // Call insertData() method of Page Model
          $value = Post::insertData($data);
          if($value){
            echo $value;
          }else{
            echo 0;
          }
    
        }else{
           echo 'Fill all fields.';
        }
    
        exit; 
      }
    
      // Update record
      public function updateUser(Request $request){
    
        $name = $request->input('name');
        $email = $request->input('email');
        $editid = $request->input('editid');
    
        if($name !='' && $email != ''){
          $data = array('name'=>$name,"email"=>$email);
    
          // Call updateData() method of Page Model
          Post::updateData($editid, $data);
          echo 'Update successfully.';
        }else{
          echo 'Fill all fields.';
        }
    
        exit; 
      }
    
      // Delete record
      public function deleteUser($id=0){
        // Call deleteData() method of Page Model
        Post::deleteData($id);
    
        echo "Delete successfully";
        exit;
      }
}
