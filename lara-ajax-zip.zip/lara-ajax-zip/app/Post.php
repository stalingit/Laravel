<?php

namespace App;
use Illuminate\Support\Facades\DB;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    public static function getuserData($id=null){

        $value=DB::table('posts')->orderBy('id', 'asc')->get(); 
        return $value;
   
      }
   
      public static function insertData($data){
   
        $value=DB::table('posts')->where('username', $data['username'])->get();
        if($value->count() == 0){
          $insertid = DB::table('posts')->insertGetId($data);
          return $insertid;
        }else{
          return 0;
        }
   
      }
   
      public static function updateData($id,$data){
         DB::table('posts')->where('id', $id)->update($data);
      }
   
      public static function deleteData($id=0){
         DB::table('posts')->where('id', '=', $id)->delete();
      }
   
   
}
