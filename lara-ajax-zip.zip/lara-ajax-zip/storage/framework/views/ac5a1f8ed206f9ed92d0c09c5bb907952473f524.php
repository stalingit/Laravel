<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <meta name="_token" content="<?php echo e(csrf_token()); ?>" />
        <title>Grocery Store</title>
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css"/>
    </head>
    <body>
      <div class="container">
         <div class="alert alert-success" style="display:none"></div>
         <div class="alert alert-danger" style="display:none"></div>
         <form id="myForm" method="post">
            <div class="form-group">
              <label for="name">Name:</label>
              <input type="text" class="form-control" id="name">
            </div>
            <div class="form-group">
              <label for="type">Type:</label>
              <input type="text" class="form-control" id="type">
            </div>
            <div class="form-group">
               <label for="price">Price:</label>
               <input type="text" class="form-control" id="price">
             </div>
            <button class="btn btn-primary" id="ajaxSubmit">Submit</button>
          </form>
      </div>
      <script src="http://code.jquery.com/jquery-3.3.1.min.js"
               integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
               crossorigin="anonymous">
      </script>
      <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
      <script>
         jQuery(document).ready(function(){
          
            jQuery('#ajaxSubmit').click(function(e){
               e.preventDefault();
               $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                  }
              });




              
               jQuery.ajax({
                  url: "<?php echo e(url('/grocery/post')); ?>",
                  method: 'post',
                  data: {
                     name: jQuery('#name').val(),
                     type: jQuery('#type').val(),
                     price: jQuery('#price').val()
                  },
                  success: function(result){
                    
                  
                      if(result.errors){

                      jQuery('.alert-danger').empty();
                        jQuery.each(result.errors, function(key, value){
                  			jQuery('.alert-danger').show();
                  			jQuery('.alert-danger').append('<p>'+value+'</p>');
                              $( ".alert-success" ).hide();
                  		});
                      }
                      else if(result.success){
                        //jQuery('.alert-danger').empty();
                        jQuery('.alert-success').show();
                     jQuery('.alert-success').html(result.success);
                     $( ".alert-danger" ).hide();

                      }

                   
                     
                  }});
               });
            });
      </script>
    </body>
</html><?php /**PATH F:\xampp\htdocs\rd\laravel-ajax\resources\views/grocery.blade.php ENDPATH**/ ?>