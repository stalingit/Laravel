<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use  App\Details;
class DetailsController extends Controller
{
    public function index(){
        $users = Details::all();
        $count = 1;
       
     return view("addeditdelete.index",["users"=>$users,"count"=>$count]);
    }
    public function addForm(){
        
       
          return view("addeditdelete.add");
     }
     public function addFormPost(Request $request){
        $this->validate($request,[
            'fname'=>'required|max:25',
            'lname'=>'required',
            'email'=>'required|email|max:255|unique:details',
        ]);
        $details = new Details;
        $details->fname = $request->input('fname');
        $details->lname = $request->input('lname');
        $details->email = $request->input('email');
        $details->save();
        return redirect('/viewdetails')->with('respose','Post Added Successfully');
     }
     public function editForm($id){
         $details = Details::find($id);
         
        return view("addeditdelete.edit",['details'=>$details]);  
     }
     public function editFormPost(Request $request,$id){
        $this->validate($request,[
            'fname'=>'required',
            'lname'=>'required',
            'email'=>'required',
        ]);
       
        $details = new Details;
        $details->fname = $request->input('fname');
        $details->lname = $request->input('lname');
        $details->email = $request->input('email');
        $data = array(
            'fname'=> $details->fname,
            'lname'=>$details->lname ,
            'email'=> $details->email

        );
        Details::where('id',$id)->update($data);
        $details->update();
        return redirect('/viewdetails')->with('respose','Post Updated Successfully');

     }
     public function deleteFormPost($id){
        Details::where('id',$id)->delete();
        return redirect('/viewdetails')->with('respose','Post Delete Successfully');
     }
}
