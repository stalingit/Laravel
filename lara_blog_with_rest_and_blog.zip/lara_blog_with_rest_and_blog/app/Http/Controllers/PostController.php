<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\DB;
use  App\Posts;
use  App\Category;
use  App\Like;
use  App\Dislike;
use  App\Comment;
use Auth;
use  App\Profile;

class PostController extends Controller
{
    public function post(){
        $categories = Category::all();
        
        return view("posts.post",['categories'=> $categories]);

    }
    public function addPost(Request $request){       
        $this->validate($request,[
            'post_title'=>'required',
            'post_body'=>'required',
            'post_image'=>'required',
            'category_id'=>'required',   
        ]);

        $post = new Posts;
        $post->post_title = $request->input('post_title');
        $post->post_body = $request->input('post_body');
        $post->user_id = Auth::user()->id;
        $post->category_id = $request->input('category_id');
        
        if(Input::hasFile('post_image')){
            $file = Input::file('post_image');
            $file->move(public_path().'/uploads/',$file->getClientOriginalName());
            $url = URL::to("/"). "/uploads/".$file->getClientOriginalName();
        }
        $post->post_image =  $url;
        
        $post->save();
        return redirect('/home')->with('respose','Post Added Successfully');
 
 
     }
     public function view($post_id){
         $posts = Posts::where('id','=',$post_id)->get();
         $likePost= Posts::find($post_id);
         
         $likeCtr = Like::where('post_id','=',$likePost->id)->count();
        
         
         $dislikeCtr = Dislike::where('post_id','=',$likePost->id)->count();
         $categories = Category::all();
         $comments = DB::table('users')
         ->join('comments', 'users.id', '=', 'comments.user_id')   
         ->join('posts', 'comments.post_id', '=', 'posts.id')        
         ->select('users.*', 'comments.*')
         ->where(['posts.id'=>$post_id])
         ->get();
        
         return view("posts.view",['posts'=> $posts,'comments'=>$comments,'categories'=>$categories,'likeCtr'=>$likeCtr,'dislikeCtr'=>$dislikeCtr]);
         


     }
     public function edit($post_id){
        $categories = Category::all();
		
        $posts = Posts::find($post_id);
        $category = Category::find($posts->category_id);
        
        return view("posts.edit",['posts'=> $posts,'categories'=>$categories,'category'=>$category]);


    }
    public function editPost(Request $request,$post_id){


        $this->validate($request,[
            'post_title'=>'required',
            'post_body'=>'required',
            'post_image'=>'required',
            'category_id'=>'required',   
        ]);

        $post = new Posts;
        $post->post_title = $request->input('post_title');
        $post->post_body = $request->input('post_body');
        $post->user_id = Auth::user()->id;
        $post->category_id = $request->input('category_id');
        
        if(Input::hasFile('post_image')){
            $file = Input::file('post_image');
            $file->move(public_path().'/uploads/',$file->getClientOriginalName());
            $url = URL::to("/"). "/uploads/".$file->getClientOriginalName();
        }
        $post->post_image =  $url;
        $data = array(
            'post_title'=>$post->post_title ,
            'post_body'=>$post->post_body,
            'user_id'=>$post->user_id,
            'category_id'=> $post->category_id,
            'post_image'=> $post->post_image


        );
        Posts::where('id',$post_id)->update($data);
        
        $post->update();
        return redirect('/home')->with('respose','Post Updated Successfully');
 


    }
    public function delete($post_id){
        Posts::where('id',$post_id)->delete();
        return redirect('/home')->with('respose','Post Delete Successfully');

    }
    public function category($cat_id){
       // echo $cat_id;
        $categories = Category::all();
                $posts = DB::table('posts')
                ->join('categories', 'posts.category_id', '=', 'categories.id')
                ->select('posts.*', 'categories.*')
                ->where(['categories.id'=>$cat_id])
                ->get(); 
               
                       
       return view('categories.categoriesposts',['categories'=>$categories,'posts'=>$posts]);

    }
    public function like($id){
        $logggedin_user = Auth::user()->id;
        $like_user = Like::where(['user_id'=> $logggedin_user,'post_id'=>$id])->first();
        if(empty( $like_user ->user_id)){
            $user_id=Auth::user()->id;
            $email=Auth::user()->email;
            $post_id =$id;
            $like = new Like();
            $like->user_id = $user_id;
            $like->post_id = $post_id;
            $like->email = $email;
            $like->save();   
            return redirect("/view/{$id}");    

        }
        else{
            return redirect("/view/{$id}");   
        }
        

    }
    public function dislike($id){
      $logggedin_user = Auth::user()->id;
        $like_user = Dislike::where(['user_id'=> $logggedin_user,'post_id'=>$id])->first();
        if(empty( $like_user ->user_id)){
            $user_id=Auth::user()->id;
            $email=Auth::user()->email;
            $post_id =$id;
            $dislike = new Dislike();
            $dislike->user_id = $user_id;
            $dislike->post_id = $post_id;
            $dislike->email = $email;
            $dislike->save();   
            return redirect("/view/{$id}");    

        }
        else{
            return redirect("/view/{$id}");   
        }
       
        

    }
    public function comment(Request $request,$id){
        $this->validate($request,[
            'comment'=>'required'
        ]);
        $comment= new Comment();
        $comment->comment = $request->input('comment');
        $user_id=Auth::user()->id;
        $comment->user_id = $user_id;
        $comment->post_id = $id;
        $comment->save();
        return redirect("/view/{$id}")->with('respose','Comment Added Successfully');

    }
    public function search(Request $request){
        $search = $request->input('search');
        $user_id=Auth::user()->id;
        $profile =      Profile::where(['user_id'=> $user_id])->first();
        $posts = Posts::where('post_title','LIKE',"%".$search."%")->get();
        return view('posts.searchposts',['posts'=>$posts,'profile'=>$profile]); 

    }
}
