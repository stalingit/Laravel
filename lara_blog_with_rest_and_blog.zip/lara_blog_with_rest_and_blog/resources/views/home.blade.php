@extends('layouts.app')
<style type="text/css">
.avatar{
    border-radius:100%;
    max-width:100px;
}

</style>
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        @if(count($errors) > 0 )
                @foreach($error->all() as $error)
                    <div class="alert alert-danger">{{$error}}</div>
                @endforeach
            @endif
            @if(session()->has('respose'))
                <div class="alert alert-success">
                    {{ session()->get('respose') }}
                </div>
            @endif
            <div class="panel panel-default">
                <div class="panel-heading">
                <div class="row">
                    <div class="col-md-12">DASHBOARD</div> 
                      
                </div>             
                
                
                
                </div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                   <div class="col-md-4">
                   @if(!empty($profile))
                   <img src="{{$profile->profile_pic}}" alt="" class="avatar">
                   @else
                   <img src="{{url('images/clients.png')}}" alt="" class="avatar">
                   @endif

                   @if(!empty($profile))
                   <p class="lead">{{$profile->name}}</p>
                   @else
                   <p></p>
                   @endif

                   @if(!empty($profile))
                   <p class="lead">{{$profile->designation}}</p>
                   @else
                   <p></p>
                   @endif

                   </div>
                   <div class="col-md-8">
                   
                  
                   
                   </div>
                 
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
