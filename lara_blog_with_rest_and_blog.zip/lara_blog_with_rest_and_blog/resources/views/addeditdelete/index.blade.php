@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        @if(count($errors) > 0 )
                @foreach($error->all() as $error)
                    <div class="alert alert-danger">{{$error}}</div>
                @endforeach
            @endif
            @if(session()->has('respose'))
                <div class="alert alert-success">
                    {{ session()->get('respose') }}
                </div>
            @endif
            <div class="panel panel-default">
                <div class="panel-heading">Add Edit Delete</div>

                <div class="panel-body">
                
                    <h2><a href="{{url('/addForm')}}">Add</a></h2>
                   
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Serial No</th>
                            <th>Firstname</th>
                            <th>Lastname</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                      
                        @if(count($users) > 0 )
                            @foreach($users->all() as $user)
                                <tr>
                                <td>{{$count++}}</td>  
                                <td>{{$user->fname}}</td>
                                <td>{{$user->lname}}</td>
                                <td>{{$user->email}}</td>
                                <td><a href='{{url("editForm/{$user->id}")}}'>Edit</a>|<a href='{{url("deleteForm/{$user->id}")}}'>Delete</a></td>
                                </tr>
                             @endforeach
                         @endif
                        
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
