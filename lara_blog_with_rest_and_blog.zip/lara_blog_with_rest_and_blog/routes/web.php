<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('welcome');
});

*/
Route::get('/', function () {
    return view('auth.login');
   
});
use Illuminate\Http\Request;
Route::post('/submit', function (Request $request) {
    $data = $request->validate([
        'title' => 'required|max:255',
        'url' => 'required|url|max:255',
        'description' => 'required|max:255',
    ]);

    $link = tap(new App\Link($data))->save();

    return redirect('/');
});


Auth::routes();
//Route::get('/home', 'HomeController@index')->name('home');
Route::get('/home', 'HomeController@index')->name('home');
Route::get('/post', 'PostController@post')->middleware('auth');
Route::get('/profile', 'ProfileController@profile')->middleware('auth');
Route::get('/category', 'CategoryController@category')->middleware('auth');
Route::post('/addCategory', 'CategoryController@addCategory')->middleware('auth');
Route::post('/addProfile', 'ProfileController@addProfile')->middleware('auth');
Route::post('/addPost', 'PostController@addPost')->middleware('auth');

Route::get('/view/{id}', 'PostController@view')->middleware('auth');

Route::get('/edit/{id}', 'PostController@edit')->middleware('auth');

Route::post('/editPost/{id}', 'PostController@editPost')->middleware('auth');


Route::get('/delete/{id}', 'PostController@delete')->middleware('auth');

Route::get('/category/{id}', 'PostController@category')->middleware('auth');

Route::get('/viewdetails', 'DetailsController@index')->middleware('auth');
Route::get('/addForm', 'DetailsController@addForm');

Route::post('/addFormPost', 'DetailsController@addFormPost');

Route::get('/editForm/{id}', 'DetailsController@editForm');
Route::post('/editFormPost/{id}', 'DetailsController@editFormPost');

Route::get('/deleteForm/{id}', 'DetailsController@deleteFormPost');


//REST API
Route::get('articles', 'ArticleController@index')->middleware('auth');
Route::get('articles/{id}', 'ArticleController@show')->middleware('auth');
Route::post('articles', 'ArticleController@store')->middleware('auth');
Route::put('articles/{id}', 'ArticleController@update')->middleware('auth');
Route::delete('articles/{id}', 'ArticleController@delete')->middleware('auth');

Route::post('register', 'Auth\RegisterController@register')->middleware('auth');

Route::get('/like/{id}', 'PostController@like')->middleware('auth');

Route::get('/dislike/{id}', 'PostController@dislike')->middleware('auth');

Route::post('/comment/{id}', 'PostController@comment')->middleware('auth');

Route::post('/search', 'PostController@search')->middleware('auth');