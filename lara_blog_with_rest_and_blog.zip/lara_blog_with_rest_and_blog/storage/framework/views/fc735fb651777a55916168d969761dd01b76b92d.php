<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        <?php if(count($errors) > 0 ): ?>
                <?php $__currentLoopData = $error->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session()->has('respose')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('respose')); ?>

                </div>
            <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">Add Edit Delete</div>

                <div class="panel-body">
                
                    <h2><a href="<?php echo e(url('/addForm')); ?>">Add</a></h2>
                   
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Serial No</th>
                            <th>Firstname</th>
                            <th>Lastname</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                      
                        <?php if(count($users) > 0 ): ?>
                            <?php $__currentLoopData = $users->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($count++); ?></td>  
                                <td><?php echo e($user->fname); ?></td>
                                <td><?php echo e($user->lname); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><a href='<?php echo e(url("editForm/{$user->id}")); ?>'>Edit</a>|<a href='<?php echo e(url("deleteForm/{$user->id}")); ?>'>Delete</a></td>
                                </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                        
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>