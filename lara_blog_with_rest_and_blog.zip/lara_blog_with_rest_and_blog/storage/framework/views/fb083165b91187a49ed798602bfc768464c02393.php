<style type="text/css">
.avatar{
    border-radius:100%;
    max-width:100px;
}

</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        <?php if(count($errors) > 0 ): ?>
                <?php $__currentLoopData = $error->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session()->has('respose')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('respose')); ?>

                </div>
            <?php endif; ?>
       
            <div class="panel panel-default">
                <div class="panel-heading">Post View</div>

                <div class="panel-body">
                    <div class="col-md-4">
                    <ul class="list-group">
                    <?php if(count($categories) > 0 ): ?>
                        <?php $__currentLoopData = $categories->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item"><a href='<?php echo e(url("category/{$category->id}")); ?>'><?php echo e($category->category); ?></a></li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php else: ?>
                     <p>Nocategory Found</p>
                     <?php endif; ?>
                     </ul>
                    
                    
                    
                    
                    
                    </div>
                    <div class="col-md-8">
                   
                        <?php if(count($posts) > 0 ): ?>
                                <?php $__currentLoopData = $posts->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h4><?php echo e($post->post_title); ?></h4>
                                    <img src="<?php echo e($post->post_image); ?>" alt="" class="avatar">
                                    <h4><?php echo e($post->post_body); ?></h4>
                                    <ul class="nav nav-pills">
                                        <li role="presentation">
                                            <a href='<?php echo e(url("/like/{$post->id}")); ?>'>Like(<?php echo e($likeCtr); ?>)</a> 
                                        </li>
                                        <li role="presentation">
                                            <a href='<?php echo e(url("/dislike/{$post->id}")); ?>'>Dislikes(<?php echo e($dislikeCtr); ?>)</a> 
                                        </li>
                                        <li role="presentation">
                                            <a href='<?php echo e(url("/comment/{$post->id}")); ?>'>Comments</a>
                                        </li>
                                    
                                    </ul>
                                   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <p>No Posts Available</p>
                            <?php endif; ?>
                            <form method="POST" action='<?php echo e(url("/comment/{$post->id}")); ?>'>
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="comment">Comment:</label>
                                    <textarea class="form-control" rows="5" name="comment" id="comment"required autofocus></textarea>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-8 col-md-offset-4">
                                        <button type="submit" class="btn btn-primary btn-lg">
                                           Post Comment
                                        </button>

                                        
                                    </div>
                                </div>
                            </form>
                            <h3>Comments</h3>
                            <?php if(count($comments) > 0 ): ?>
                                <?php $__currentLoopData = $comments->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($comment->comment); ?></p>
                                    <p>Posted By:<?php echo e($comment->name); ?></p>
                                    <hr/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <p>No Posts Available</p>
                            <?php endif; ?>
                   
                   
                   </div>
                    

                  
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>