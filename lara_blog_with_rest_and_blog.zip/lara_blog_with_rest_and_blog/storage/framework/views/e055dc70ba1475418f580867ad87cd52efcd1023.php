    <?php $__env->startSection('title', 'Contact'); ?>
    <?php $__env->startSection('content'); ?>
        <div class="container">
            <div class="content">
                <div class="title">Contact page</div>
                <div class="quote">Our Contact Page</div>
            </div>
        </div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>