<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Disable all mass assignment restrictions
    Model::unguard();
 
   // $this->call(PostsTableSeeder::class);
    $this->call(LinksTableSeeder::class);
    $this->call(ArticlesTableSeeder::class);
    $this->call(RegisterusersTableSeeder::class);
 
    // Re enable all mass assignment restrictions
    Model::reguard();
    }
}
