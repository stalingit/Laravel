<?php

use Illuminate\Database\Seeder;

class PostsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       factory('App\Post', 10)->create();
	   factory('App\Post')->states('active')->create();
	   // Create a new featured post
factory('App\Post')->states('featured')->create();
 
// Create a new active featured post
factory('App\Post')->states('active', 'featured')->create();
    }
}
