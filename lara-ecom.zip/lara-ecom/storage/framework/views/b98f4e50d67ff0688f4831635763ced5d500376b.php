<?php /* F:\xampp\htdocs\rd\laravel-ecommerce-example-master\laravel-ecommerce-example-master\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php */ ?>
[<?php echo e($slot); ?>](<?php echo e($url); ?>)
